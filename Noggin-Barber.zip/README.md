# NogginBarber.com
This is the website for Kidd and Play Photography, Kendra Kidd's photography service in the Indianapolis area.
